package com.example.careerguidence;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "colleges")
public class CollegeEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    public String city;
    public String course;
    public String website;

    public CollegeEntity(String name, String city, String course, String website) {
        this.name = name;
        this.city = city;
        this.course = course;
        this.website = website;
    }
}