package com.example.careerguidence;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_USER = 0;
    private static final int TYPE_BOT = 1;

    ArrayList<ChatMessage> list;

    public ChatAdapter(ArrayList<ChatMessage> list) {
        this.list = list;
    }

    @Override
    public int getItemViewType(int position) {
        if (list.get(position).isUser()) {
            return TYPE_USER;
        } else {
            return TYPE_BOT;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        if (viewType == TYPE_USER) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_user_message, parent, false);
            return new UserViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_bot_message, parent, false);
            return new BotViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(
            @NonNull RecyclerView.ViewHolder holder, int position) {

        ChatMessage msg = list.get(position);

        if (holder instanceof UserViewHolder) {
            ((UserViewHolder) holder).txtMessage.setText(msg.getMessage());
        } else {
            ((BotViewHolder) holder).txtMessage.setText(msg.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView txtMessage;

        UserViewHolder(View itemView) {
            super(itemView);
            txtMessage = itemView.findViewById(R.id.txtUserMessage);
        }
    }

    static class BotViewHolder extends RecyclerView.ViewHolder {
        TextView txtMessage;

        BotViewHolder(View itemView) {
            super(itemView);
            txtMessage = itemView.findViewById(R.id.txtBotMessage);
        }
    }
}
