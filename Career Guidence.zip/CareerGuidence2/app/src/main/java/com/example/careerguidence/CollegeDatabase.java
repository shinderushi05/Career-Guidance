package com.example.careerguidence;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {CollegeEntity.class}, version = 1)
public abstract class CollegeDatabase extends RoomDatabase {

    private static CollegeDatabase instance;

    public abstract CollegeDao collegeDao();

    public static synchronized CollegeDatabase getInstance(Context context) {

        if (instance == null) {
            instance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    CollegeDatabase.class,
                    "college_database"
            ).allowMainThreadQueries().build();
        }

        return instance;
    }
}