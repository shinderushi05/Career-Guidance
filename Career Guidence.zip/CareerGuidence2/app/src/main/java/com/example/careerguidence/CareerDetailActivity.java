package com.example.careerguidence;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CareerDetailActivity extends AppCompatActivity {

    TextView tvTitle,tvDescription,tvSkills,tvSalary,tvColleges,tvFuture,tvRoadmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_career_detail);

        tvTitle = findViewById(R.id.tvTitle);
        tvDescription = findViewById(R.id.tvDescription);
        tvSkills = findViewById(R.id.tvSkills);
        tvSalary = findViewById(R.id.tvSalary);
        tvColleges = findViewById(R.id.tvColleges);
        tvFuture = findViewById(R.id.tvFuture);
        tvRoadmap = findViewById(R.id.tvRoadmap);

        String title = getIntent().getStringExtra("title");
        String description = getIntent().getStringExtra("description");
        String skills = getIntent().getStringExtra("skills");
        String salary = getIntent().getStringExtra("salary");
        String colleges = getIntent().getStringExtra("colleges");
        String future = getIntent().getStringExtra("future");
        String roadmap = getIntent().getStringExtra("roadmap");

        tvTitle.setText(title);
        tvDescription.setText(description);
        tvSkills.setText("Skills: "+skills);
        tvSalary.setText("Salary: "+salary);
        tvColleges.setText("Top Colleges: "+colleges);
        tvFuture.setText("Future Scope: "+future);
        tvRoadmap.setText(roadmap);
    }
}