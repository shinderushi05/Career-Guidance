package com.example.careerguidence;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText etName, etAge;
    private Spinner spinnerEducation;
    private CheckBox cbScience, cbArts, cbCommerce, cbTech, cbCreative, cbBusiness;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        spinnerEducation = findViewById(R.id.spinnerEducation);

        cbScience = findViewById(R.id.cbScience);
        cbArts = findViewById(R.id.cbArts);
        cbCommerce = findViewById(R.id.cbCommerce);
        cbTech = findViewById(R.id.cbTech);
        cbCreative = findViewById(R.id.cbCreative);
        cbBusiness = findViewById(R.id.cbBusiness);

        // Education spinner data
        String[] levels = {"10th Grade", "12th Grade", "College"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                levels
        );

        spinnerEducation.setAdapter(adapter);

        // Load saved profile data
        SharedPreferences prefs = getSharedPreferences("CareerApp", MODE_PRIVATE);

        String savedName = prefs.getString("name", "");
        int savedAge = prefs.getInt("age", 0);

        if (!savedName.isEmpty()) {
            etName.setText(savedName);
        }

        if (savedAge != 0) {
            etAge.setText(String.valueOf(savedAge));
        }

        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(v -> saveAndProceed());
    }

    private void saveAndProceed() {

        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();

        // Name validation
        if (name.isEmpty()) {
            etName.setError("Enter your name");
            return;
        }

        // Age validation
        if (ageStr.isEmpty()) {
            etAge.setError("Enter your age");
            return;
        }

        int age;

        try {
            age = Integer.parseInt(ageStr);
        } catch (Exception e) {
            Toast.makeText(this, "Enter valid age", Toast.LENGTH_SHORT).show();
            return;
        }

        if (age < 10 || age > 60) {
            Toast.makeText(this, "Age should be between 10 and 60", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check interests
        if (!cbScience.isChecked() &&
                !cbArts.isChecked() &&
                !cbCommerce.isChecked() &&
                !cbTech.isChecked() &&
                !cbCreative.isChecked() &&
                !cbBusiness.isChecked()) {

            Toast.makeText(this, "Select at least one interest", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save data
        SharedPreferences prefs = getSharedPreferences("CareerApp", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("name", name);
        editor.putInt("age", age);
        editor.putString("education", spinnerEducation.getSelectedItem().toString());

        StringBuilder interests = new StringBuilder();

        if (cbScience.isChecked()) interests.append("Science,");
        if (cbArts.isChecked()) interests.append("Arts,");
        if (cbCommerce.isChecked()) interests.append("Commerce,");
        if (cbTech.isChecked()) interests.append("Technology,");
        if (cbCreative.isChecked()) interests.append("Creativity,");
        if (cbBusiness.isChecked()) interests.append("Business,");

        editor.putString("interests", interests.toString());

        editor.apply();

        // Go to Quiz
        Intent intent = new Intent(ProfileActivity.this, QuizActivity.class);
        startActivity(intent);
        finish();
    }
}