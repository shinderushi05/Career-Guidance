package com.example.careerguidence;

import java.util.ArrayList;
import java.util.List;

public class CollegeData {

    public static List<CollegeEntity> getColleges() {

        List<CollegeEntity> list = new ArrayList<>();

        list.add(new CollegeEntity("IIT Bombay", "Mumbai", "Engineering", "https://www.iitb.ac.in"));
        list.add(new CollegeEntity("COEP Technological University", "Pune", "Engineering", "https://www.coep.org.in"));
        list.add(new CollegeEntity("VJTI", "Mumbai", "Engineering", "https://vjti.ac.in"));
        list.add(new CollegeEntity("MIT World Peace University", "Pune", "Engineering", "https://mitwpu.edu.in"));
        list.add(new CollegeEntity("DY Patil College of Engineering", "Pune", "Engineering", "https://engg.dypvp.edu.in"));

        list.add(new CollegeEntity("BJ Medical College", "Pune", "Medical", "https://www.bjmcpune.org"));
        list.add(new CollegeEntity("Grant Medical College", "Mumbai", "Medical", "https://www.gmcjjh.org"));
        list.add(new CollegeEntity("AFMC", "Pune", "Medical", "https://afmc.nic.in"));

        list.add(new CollegeEntity("Symbiosis College", "Pune", "Management", "https://www.symbiosis.ac.in"));
        list.add(new CollegeEntity("NMIMS University", "Mumbai", "Management", "https://www.nmims.edu"));

        list.add(new CollegeEntity("Fergusson College", "Pune", "Arts/Science", "https://www.fergusson.edu"));
        list.add(new CollegeEntity("St Xavier's College", "Mumbai", "Arts/Science", "https://xaviers.edu"));

        list.add(new CollegeEntity("Savitribai Phule Pune University", "Pune", "All Courses", "https://www.unipune.ac.in"));
        list.add(new CollegeEntity("Mumbai University", "Mumbai", "All Courses", "https://mu.ac.in"));

        list.add(new CollegeEntity("Walchand College of Engineering", "Sangli", "Engineering", "https://www.walchandsangli.ac.in"));

        list.add(new CollegeEntity("Government College of Engineering", "Karad", "Engineering", "https://www.gcekarad.ac.in"));

        list.add(new CollegeEntity("KIT College of Engineering", "Kolhapur", "Engineering", "https://www.kitcoek.in"));

        list.add(new CollegeEntity("DY Patil Medical College", "Kolhapur", "Medical", "https://dypatil.edu"));

        list.add(new CollegeEntity("Shivaji University", "Kolhapur", "All Courses", "https://www.unishivaji.ac.in"));

        list.add(new CollegeEntity("Rajarambapu Institute of Technology", "Sangli", "Engineering", "https://www.ritindia.edu"));

        return list;
    }
}