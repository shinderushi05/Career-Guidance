package com.example.careerguidence;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface CollegeDao {

    @Insert
    void insertAll(List<CollegeEntity> colleges);

    @Query("SELECT * FROM colleges")
    List<CollegeEntity> getAllColleges();

    @Query("SELECT * FROM colleges WHERE city LIKE :city AND course LIKE :course")
    List<CollegeEntity> filterColleges(String city, String course);
}