package com.example.careerguidence;

public class College {
    String name, course;

    public College(String name, String course) {
        this.name = name;
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }
}
