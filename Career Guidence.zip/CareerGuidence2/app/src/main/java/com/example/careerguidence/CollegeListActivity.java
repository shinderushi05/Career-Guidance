package com.example.careerguidence;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CollegeListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    CollegeAdapter adapter;
    CollegeDatabase db;

    EditText edtCity, edtCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_list);

        // Initialize Views
        recyclerView = findViewById(R.id.recyclerCollege);
        edtCity = findViewById(R.id.edtCity);
        edtCourse = findViewById(R.id.edtCourse);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Database instance
        db = CollegeDatabase.getInstance(this);

        // Insert colleges only first time
        new Thread(() -> {
            if (db.collegeDao().getAllColleges().size() == 0) {
                db.collegeDao().insertAll(CollegeData.getColleges());
            }

            runOnUiThread(() -> loadFilteredData());

        }).start();


        // Text watcher for search
        TextWatcher watcher = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadFilteredData();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        edtCity.addTextChangedListener(watcher);
        edtCourse.addTextChangedListener(watcher);
    }


    private void loadFilteredData() {

        new Thread(() -> {

            String city = "%" + edtCity.getText().toString().trim() + "%";
            String course = "%" + edtCourse.getText().toString().trim() + "%";

            List<CollegeEntity> list =
                    db.collegeDao().filterColleges(city, course);

            runOnUiThread(() -> {
                adapter = new CollegeAdapter(this, list);
                recyclerView.setAdapter(adapter);
            });

        }).start();

    }
}