package com.example.careerguidence;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class DashboardActivity extends AppCompatActivity {

    CardView cardChatBot, cardCollege, cardCareer;

    String careerType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        cardChatBot = findViewById(R.id.cardChatBot);
        cardCollege = findViewById(R.id.cardCollege);
        cardCareer = findViewById(R.id.cardCareer);

        // Receive career from ResultActivity
        careerType = getIntent().getStringExtra("career");

        // Prevent crash if null
        if (careerType == null) {
            careerType = "Science";
        }

        // ChatBot Click
        cardChatBot.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ChatBotActivity.class);
            startActivity(intent);
        });

        // College Click
        cardCollege.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, CollegeListActivity.class);
            startActivity(intent);
        });

        // Career Roadmap Click
        cardCareer.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, CareerRoadmapActivity.class);
            intent.putExtra("career", careerType);
            startActivity(intent);
        });
    }
}