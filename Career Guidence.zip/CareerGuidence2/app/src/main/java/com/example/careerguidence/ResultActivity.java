package com.example.careerguidence;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    LinearLayout careerContainer;
    Button btnGoDashboard;

    int sciencePer, artsPer, commercePer, techPer;

    // GLOBAL VARIABLE
    String bestCareerType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        careerContainer = findViewById(R.id.careerContainer);
        btnGoDashboard = findViewById(R.id.btnGoDashboard);

        loadResults();

        btnGoDashboard.setOnClickListener(v -> {

            Intent intent = new Intent(ResultActivity.this, DashboardActivity.class);
            intent.putExtra("career", bestCareerType);

            startActivity(intent);

            finish(); // closes ResultActivity
        });
    }

    private void loadResults() {

        // Receive data from QuizActivity
        sciencePer = getIntent().getIntExtra("science", 0);
        artsPer = getIntent().getIntExtra("arts", 0);
        commercePer = getIntent().getIntExtra("commerce", 0);
        techPer = getIntent().getIntExtra("tech", 0);

        addCareerCard(
                "Science Stream",
                sciencePer + "%",
                "Engineering, Doctor, Researcher, Scientist"
        );

        addCareerCard(
                "Arts Stream",
                artsPer + "%",
                "Writer, Designer, Psychologist, Journalist"
        );

        addCareerCard(
                "Commerce Stream",
                commercePer + "%",
                "CA, MBA, Banker, Business Analyst"
        );

        addCareerCard(
                "Technology Stream",
                techPer + "%",
                "Software Developer, AI Engineer, Cyber Security"
        );

        showBestCareer();
    }

    private void showBestCareer() {

        int max = Math.max(Math.max(sciencePer, artsPer),
                Math.max(commercePer, techPer));

        String bestCareer;

        if (max == sciencePer) {

            bestCareerType = "Science";

            bestCareer = "🔥 Recommended Career: SCIENCE\n\n" +
                    "Best Fields:\n" +
                    "• Engineering\n" +
                    "• Medical\n" +
                    "• Research\n" +
                    "• Biotechnology";

        } else if (max == artsPer) {

            bestCareerType = "Arts";

            bestCareer = "🔥 Recommended Career: ARTS\n\n" +
                    "Best Fields:\n" +
                    "• Journalism\n" +
                    "• Psychology\n" +
                    "• Design\n" +
                    "• Literature";

        } else if (max == commercePer) {

            bestCareerType = "Commerce";

            bestCareer = "🔥 Recommended Career: COMMERCE\n\n" +
                    "Best Fields:\n" +
                    "• Chartered Accountant (CA)\n" +
                    "• MBA\n" +
                    "• Banking\n" +
                    "• Business Management";

        } else {

            bestCareerType = "Technology";

            bestCareer = "🔥 Recommended Career: TECHNOLOGY\n\n" +
                    "Best Fields:\n" +
                    "• Software Development\n" +
                    "• Artificial Intelligence\n" +
                    "• Cyber Security\n" +
                    "• Data Science";
        }

        addBestCareerCard(bestCareer);
    }

    private void addCareerCard(String title, String percentage, String careers) {

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(40, 40, 40, 40);
        card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);

        params.setMargins(0, 0, 0, 30);
        card.setLayoutParams(params);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title + " : " + percentage);
        tvTitle.setTextSize(18);
        tvTitle.setGravity(Gravity.START);

        TextView tvCareers = new TextView(this);
        tvCareers.setText("Possible Careers:\n" + careers);
        tvCareers.setTextSize(15);

        card.addView(tvTitle);
        card.addView(tvCareers);

        careerContainer.addView(card);
    }

    private void addBestCareerCard(String text) {

        TextView tvBest = new TextView(this);
        tvBest.setText(text);
        tvBest.setTextSize(20);
        tvBest.setPadding(30, 40, 30, 40);
        tvBest.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

        careerContainer.addView(tvBest);
    }
}