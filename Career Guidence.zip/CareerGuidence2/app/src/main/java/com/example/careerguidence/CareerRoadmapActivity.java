package com.example.careerguidence;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CareerRoadmapActivity extends AppCompatActivity {

    TextView tvRoadmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_career_roadmap);

        tvRoadmap = findViewById(R.id.tvRoadmap);

        String career = getIntent().getStringExtra("career");

        if (career == null) {
            tvRoadmap.setText("Career roadmap not available.");
            return;
        }

        if (career.equals("Science")) {

            tvRoadmap.setText(
                    "SCIENCE CAREER ROADMAP\n\n" +

                            "After 10th:\n" +
                            "Choose Science Stream (PCM or PCB)\n\n" +

                            "After 12th:\n" +
                            "Engineering (B.Tech)\n" +
                            "Medical (MBBS)\n" +
                            "B.Sc Research\n\n" +

                            "Required Skills:\n" +
                            "• Problem Solving\n" +
                            "• Analytical Thinking\n" +
                            "• Logical Skills\n\n" +

                            "Salary Range:\n" +
                            "₹5 LPA – ₹25 LPA\n\n" +

                            "Future Scope:\n" +
                            "High demand in Technology, Medical, Research fields"
            );

        }
        else if (career.equals("Commerce")) {

            tvRoadmap.setText(
                    "COMMERCE CAREER ROADMAP\n\n" +

                            "After 10th:\n" +
                            "Choose Commerce Stream\n\n" +

                            "After 12th:\n" +
                            "B.Com\n" +
                            "BBA\n" +
                            "CA / CS / CMA\n\n" +

                            "Required Skills:\n" +
                            "• Financial Knowledge\n" +
                            "• Business Understanding\n\n" +

                            "Salary Range:\n" +
                            "₹4 LPA – ₹20 LPA\n\n" +

                            "Future Scope:\n" +
                            "Banking, Finance, Corporate Industry"
            );

        }
        else if (career.equals("Arts")) {

            tvRoadmap.setText(
                    "ARTS CAREER ROADMAP\n\n" +

                            "After 10th:\n" +
                            "Choose Arts / Humanities\n\n" +

                            "After 12th:\n" +
                            "BA\n" +
                            "Journalism\n" +
                            "Psychology\n" +
                            "Design\n\n" +

                            "Required Skills:\n" +
                            "• Creativity\n" +
                            "• Communication\n\n" +

                            "Salary Range:\n" +
                            "₹3 LPA – ₹15 LPA\n\n" +

                            "Future Scope:\n" +
                            "Media, Design, Civil Services"
            );

        }
        else {

            tvRoadmap.setText(
                    "TECHNOLOGY CAREER ROADMAP\n\n" +

                            "After 10th:\n" +
                            "Focus on Computer Skills\n\n" +

                            "After 12th:\n" +
                            "B.Tech Computer Science\n" +
                            "BCA\n" +
                            "Software Development Courses\n\n" +

                            "Required Skills:\n" +
                            "• Programming\n" +
                            "• Logical Thinking\n\n" +

                            "Salary Range:\n" +
                            "₹6 LPA – ₹40 LPA\n\n" +

                            "Future Scope:\n" +
                            "AI, Cyber Security, Software Development"
            );

        }

    }
}