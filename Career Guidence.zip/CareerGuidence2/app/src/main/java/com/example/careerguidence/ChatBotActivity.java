package com.example.careerguidence;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatBotActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    EditText edtMessage;
    Button btnSend;

    ArrayList<ChatMessage> list;
    ChatAdapter adapter;

    // ✅ TIMEOUT FIX (IMPORTANT)
    OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build();

    // 🔴 CHANGE IP TO YOUR LAPTOP IP
    String SERVER_URL = "http://192.168.1.102:5000/chat";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        recyclerView = findViewById(R.id.recyclerChat);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);

        list = new ArrayList<>();
        adapter = new ChatAdapter(list);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnSend.setOnClickListener(v -> {
            String userMsg = edtMessage.getText().toString().trim();

            if (!userMsg.isEmpty()) {
                list.add(new ChatMessage(userMsg, true));
                adapter.notifyDataSetChanged();
                edtMessage.setText("");

                sendToAI(userMsg);
            }
        });
    }

    private void sendToAI(String message) {

        try {
            JSONObject json = new JSONObject();
            json.put("message", message);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                    .url(SERVER_URL)
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {

                @Override
                public void onFailure(Call call, IOException e) {
                    runOnUiThread(() -> {
                        list.add(new ChatMessage("AI server not responding ❌", false));
                        adapter.notifyDataSetChanged();
                    });
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    if (response.isSuccessful() && response.body() != null) {

                        String res = response.body().string();

                        try {
                            // ✅ JSON PARSING FIX
                            JSONObject obj = new JSONObject(res);
                            String reply = obj.getString("reply");

                            runOnUiThread(() -> {
                                list.add(new ChatMessage(reply.trim(), false));
                                adapter.notifyDataSetChanged();
                                recyclerView.scrollToPosition(list.size() - 1);
                            });

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        runOnUiThread(() -> {
                            list.add(new ChatMessage("AI error ❌", false));
                            adapter.notifyDataSetChanged();
                        });
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
