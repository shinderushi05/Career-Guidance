package com.example.careerguidence;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    private int currentQuestion = 0;

    // 0 = Science | 1 = Arts | 2 = Commerce | 3 = Technology
    private int[] scores = new int[4];

    private TextView tvQuestion, tvProgress;
    private RadioGroup radioGroup;
    private RadioButton rb1, rb2, rb3, rb4;
    private Button btnNext;

    // Questions
    private String[][] questions = {

            {"What type of problems do you enjoy solving?",
                    "Scientific problems",
                    "Understanding people",
                    "Financial planning",
                    "Technical issues"},

            {"What do you enjoy doing in free time?",
                    "Science experiments",
                    "Drawing or writing",
                    "Learning about business",
                    "Coding or using technology"},

            {"Which subject do you like the most?",
                    "Physics / Chemistry",
                    "History / Literature",
                    "Economics / Accounts",
                    "Computer Science"},

            {"What kind of work environment do you prefer?",
                    "Research lab",
                    "Creative studio",
                    "Business office",
                    "Tech company"},

            {"What motivates you most?",
                    "Discovering new things",
                    "Expressing creativity",
                    "Making money",
                    "Building new technology"},

            {"What kind of projects excite you?",
                    "Science research",
                    "Art and design",
                    "Business planning",
                    "App or software development"},

            {"What skill describes you best?",
                    "Analytical thinking",
                    "Creative thinking",
                    "Management skills",
                    "Problem solving with technology"},

            {"What would you enjoy learning?",
                    "Biology and chemistry",
                    "Psychology and literature",
                    "Finance and marketing",
                    "Programming and AI"},

            {"Your dream job is?",
                    "Scientist / Doctor",
                    "Writer / Designer",
                    "Entrepreneur",
                    "Software Engineer"},

            {"What would you like to contribute to society?",
                    "Medical discoveries",
                    "Art and culture",
                    "Economic growth",
                    "Technological innovation"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        tvQuestion = findViewById(R.id.tvQuestion);
        tvProgress = findViewById(R.id.tvProgress);

        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        rb4 = findViewById(R.id.rb4);

        btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(v -> processAnswer());

        displayQuestion();
    }

    private void displayQuestion() {

        tvProgress.setText("Question " + (currentQuestion + 1) + " of " + questions.length);

        tvQuestion.setText(questions[currentQuestion][0]);

        rb1.setText(questions[currentQuestion][1]);
        rb2.setText(questions[currentQuestion][2]);
        rb3.setText(questions[currentQuestion][3]);
        rb4.setText(questions[currentQuestion][4]);

        radioGroup.clearCheck();
    }

    private void processAnswer() {

        int selected = radioGroup.getCheckedRadioButtonId();

        if (selected == -1) {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selected == R.id.rb1) scores[0]++;
        else if (selected == R.id.rb2) scores[1]++;
        else if (selected == R.id.rb3) scores[2]++;
        else if (selected == R.id.rb4) scores[3]++;

        currentQuestion++;

        if (currentQuestion < questions.length) {
            displayQuestion();
        } else {
            calculateResult();
        }
    }

    private void calculateResult() {

        int totalQuestions = questions.length;

        int sciencePercent = (scores[0] * 100) / totalQuestions;
        int artsPercent = (scores[1] * 100) / totalQuestions;
        int commercePercent = (scores[2] * 100) / totalQuestions;
        int techPercent = (scores[3] * 100) / totalQuestions;

        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);

        intent.putExtra("science", sciencePercent);
        intent.putExtra("arts", artsPercent);
        intent.putExtra("commerce", commercePercent);
        intent.putExtra("tech", techPercent);

        startActivity(intent);
        finish(); // closes quiz activity
    }
}